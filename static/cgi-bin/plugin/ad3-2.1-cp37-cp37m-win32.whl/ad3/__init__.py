__version__ = '2.1.dev0'

from .factor_graph import PBinaryVariable, PFactorGraph, PMultiVariable
from .simple_inference import simple_grid, general_graph
